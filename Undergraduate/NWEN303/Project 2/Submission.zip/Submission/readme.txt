For the programs in part 3 and part 5 make sure to compile the Client java file before running the Tester.
