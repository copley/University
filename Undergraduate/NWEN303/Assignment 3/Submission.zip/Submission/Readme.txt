To run assignment code use the folowing command
java -jar "Assignment 3.jar" <max number of people> <delay> <maze file>
