cp comp304a1.lhs COMP304A1.lhs
runhaskell comp304a1.test.hs
