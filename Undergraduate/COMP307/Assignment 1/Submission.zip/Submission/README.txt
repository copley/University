All source code is in code.zip. Ensure all jars are run in the same directory as the data folder as then they can refer to the correct files

DECISION TREE JAR
To run the decison tree use the command "java -jar DecisonTree.jar"

DECISION TREE RUNS JAR
To run the decison tree use the command "java -jar DecisonTreeRuns.jar"

PERCEPTRON JAR
To run the decison tree use the command "java -jar Perceptron.jar". You will be prompted by a file select box to choose the training data. Once training has finished then you will be presented with the file picker again to pick testing data. The testing data that i created is the file '/data/part3/test.data'

K MEANS CLUSTERING JAR
To run the decison tree use the command "java -jar KMeansClustering.jar"

NEAREST NEIGHBOURS JAR
To run the decison tree use the command "java -jar NearestNeighbours.jar"
